public class Calculate 
{
	public static int square(int x) 
	{
		int answer = (x*x);
		return answer;
	}
	
	public static int cube(int x) 
	{
		int answer = (x*x*x);
		return answer;
	}
	
	public static double average(double x, double y) 
	{
		double answer = ((x+x)/2);
		return answer;
	}
	
	public static double average(double x, double y, double z) 
	{
		double answer = ((x+y+z)/3);
		return answer;
	}
	
	public static double toDegrees(double x) 
	{
		double answer = (x*(180/3.14159));
		return answer;
	}
	
	public static double toRadians(double x) 
	{
		double answer = (x*(3.14159/180));
		return answer;
	}
	
   public static double discriminant(double a, double b, double c) 	
   {
		double answer = ((b*b) - (4*a*c));
		return answer;
	}
	
	public static String toImproperFrac(int wholeNumber, int numerator, int denominator) 
	{
		int ab = (wholeNumber*denominator + numerator);
	    String answer = ab + "/" + denominator;
		return answer;
	}

	public static String toMixedNum(int x, int y) 
	{
		int answer1 = x/y;
		int answer2 = (x % y);
		String answer3 = answer1 + "_" + answer2 + "/" + y;
		return answer3;
	}
	
	public static String foil(int a, int b, int c, int d, String x) 
	{
		int ac = (a*c);
		int ad = (a*d);
		int bc = (b*c);
		int bd = (b*d);
		String x1 = x + "^2";
		String answer1 = ac + x1 + " + " + (ad+bc) + x + " " + bd;
		String answer2= answer1.toString();
		return answer2;
	}
	
	public static boolean isDivisibleBy(int a, int b) 
	{
		boolean answer = true;
		if ((a%b) == 0)
		{
			answer = true;
		}
		else 
		{
			answer = false;
		}
		return answer;
	}
	
	public static double absValue(double a) 
	{
		double value = a * -1;
		return value;
	}
	
	public static double max(double a, double b) 
	{
		if (a > b)
		{
			return a;
		}
		else
		{ 
			return b;
		}
	}
	
	public static double max(double a, double b, double c) 
	{
		if (a > b) 
		{
			return a;
		}
		else if (a > c) 
		{
			return a;
		}
		else if (b > a)
		{
			return b;
		}
		else if (b > c)
		{
			return b;
		}
		else if (c > b)
		{
			return c;
		}
		else
		{
			return c;
		}
		
	}

	public static int min(int a, int b) 
	{
		if (a < b)
		{
			return a;
		}
		else
		{ 
			return b;
		}
	}
	
	public static double round2(double a) 
	{
		double answer = a;
		
		answer = a * 1000;
		if ((answer % 10) > 5) {
			double minusTen = 10 - (answer % 10);
			answer = answer + minusTen;
			answer = answer / 1000;
		} else  {
			answer = a * 100;
			answer = (int) answer;
			answer = answer / 100;
		}
		
		return answer;		
	}
	
	public static double exponent(double base, int exponent)
	{
		int counter = 1;
		double original = base;
		while (counter != exponent) {
			counter += 1;
			base *= original;
		}
		
		return base;
		
	}
	
	public static int factorial(int number)
	{
		int count = 1;
		int originalNumber = number;
			
		while (count <= originalNumber)
		{
			count += 1;
			originalNumber -= 1;
			number *= originalNumber;
		}
		
		return number;
		
	}
	
}
